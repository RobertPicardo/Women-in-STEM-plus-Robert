import java.io.*;
import java.util.*;
import java.util.regex.*;
import org.jfree.chart.*;
import org.jfree.chart.plot.*;
import org.jfree.data.xy.*;

public class TaskAnalyzer {

    static class TaskData {
        boolean success;
        double duration;
        double pathLength;
    }

    public static void main(String[] args) throws Exception {

        String file1 = "file1.txt";
        String file2 = "file2.txt";

        List<TaskData> data1 = processFile(file1);
        List<TaskData> data2 = processFile(file2);

        printStats("File 1", data1);
        printStats("File 2", data2);

        createGraph(data1, data2);
    }

    // ================= FILE PROCESSING =================
    public static List<TaskData> processFile(String filename) throws Exception {
        BufferedReader br = new BufferedReader(new FileReader(filename));
        String line;

        List<TaskData> tasks = new ArrayList<>();

        List<double[]> positions = new ArrayList<>();
        double startTime = -1;
        double endTime = -1;

        while ((line = br.readLine()) != null) {

            // TIMESTAMP
            if (line.startsWith("TIMESTAMP:")) {
                double t = Double.parseDouble(line.split(":")[1].trim());
                if (startTime == -1) startTime = t;
                endTime = t;
            }

            // ee_position
            if (line.contains("'ee_position'")) {
                Pattern p = Pattern.compile("\\[(.*?)\\]");
                Matcher m = p.matcher(line);
                if (m.find()) {
                    String[] nums = m.group(1).split(",");
                    double[] pos = new double[3];
                    for (int i = 0; i < 3; i++) {
                        pos[i] = Double.parseDouble(nums[i].trim());
                    }
                    positions.add(pos);
                }
            }

            // TASK RESULT
            if (line.startsWith("TASK_STATUS:")) {
                TaskData task = new TaskData();

                task.success = line.contains("SUCCESS");

                // Read duration
                String durationLine = br.readLine();
                double duration = Double.parseDouble(durationLine.split(":")[1].trim());
                task.duration = duration;

                // Compute path length
                task.pathLength = computePathLength(positions);

                tasks.add(task);

                // Reset for next task
                positions.clear();
                startTime = -1;
                endTime = -1;
            }
        }

        br.close();
        return tasks;
    }

    // ================= PATH LENGTH =================
    public static double computePathLength(List<double[]> positions) {
        double length = 0.0;

        for (int i = 1; i < positions.size(); i++) {
            double[] p1 = positions.get(i - 1);
            double[] p2 = positions.get(i);

            double dist = Math.sqrt(
                Math.pow(p2[0] - p1[0], 2) +
                Math.pow(p2[1] - p1[1], 2) +
                Math.pow(p2[2] - p1[2], 2)
            );

            length += dist;
        }

        return length;
    }

    // ================= STATS =================
    public static void printStats(String name, List<TaskData> tasks) {
        int total = tasks.size();
        int successCount = 0;

        double totalTime = 0;
        double totalPath = 0;

        for (TaskData t : tasks) {
            if (t.success) {
                successCount++;
                totalTime += t.duration;
                totalPath += t.pathLength;
            }
        }

        double successRate = (double) successCount / total;
        double avgTime = successCount > 0 ? totalTime / successCount : 0;
        double avgPath = successCount > 0 ? totalPath / successCount : 0;

        System.out.println("==== " + name + " ====");
        System.out.println("Success Rate: " + successRate);
        System.out.println("Avg Completion Time: " + avgTime);
        System.out.println("Avg Training Time: " + avgTime);
        System.out.println("Avg Path Length: " + avgPath);
        System.out.println();
    }

    // ================= GRAPH =================
    public static void createGraph(List<TaskData> data1, List<TaskData> data2) {

        XYSeries series1 = new XYSeries("File 1");
        XYSeries series2 = new XYSeries("File 2");

        for (TaskData t : data1) {
            if (t.success) {
                series1.add(t.duration, t.pathLength);
            }
        }

        for (TaskData t : data2) {
            if (t.success) {
                series2.add(t.duration, t.pathLength);
            }
        }

        XYSeriesCollection dataset = new XYSeriesCollection();
        dataset.addSeries(series1);
        dataset.addSeries(series2);

        JFreeChart chart = ChartFactory.createXYLineChart(
                "Task Comparison",
                "Time (s)",
                "Path Length",
                dataset,
                PlotOrientation.VERTICAL,
                true, true, false
        );

        try {
            ChartFrame frame = new ChartFrame("Graph", chart);
            frame.pack();
            frame.setVisible(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}